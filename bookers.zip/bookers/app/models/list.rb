class List < ApplicationRecord

end
